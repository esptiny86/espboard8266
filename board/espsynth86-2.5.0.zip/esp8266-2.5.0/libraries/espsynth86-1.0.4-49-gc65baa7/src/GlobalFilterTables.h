#ifndef FILTER_TABLES
#define FILTER_TABLES

extern const uint16_t LPF_P_TABLE[] PROGMEM;
extern const uint16_t LPF_T4_TABLE[] PROGMEM;
#endif
