#ifndef ESPSYNTH_H
#define ESPSYNTH_H

#include "AnalogMultiplexer.h"
#include "Module.h"
#include "Synth.h"
#include "SynthExtended.h"
#include "SynthManager.h"
#include "OSCBundleReader.h"

#endif // ESPSYNTH_H
