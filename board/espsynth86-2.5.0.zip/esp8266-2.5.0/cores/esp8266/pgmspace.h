// pgmspace.h stub

// This file's contents have been moved to newlib.  This file simply
// includes the newlib pgmspace file as well as some ets headers
// to preserve backwards compatibility

#include <sys/pgmspace.h>

#ifdef __ets__

#include "ets_sys.h"
#include "osapi.h"

#endif
