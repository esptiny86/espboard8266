#ifndef Chords_h
#define Chords_h

extern const uint8_t CHORDS[][3];

#endif