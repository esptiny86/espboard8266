#include "Arduino.h"
#include "Defines.h"

#ifndef RingBuffer_h
#define RingBuffer_h

extern uint16_t RING_BUFFER[RING_BUFFER_SIZE];

#endif
