#ifndef Wavetables_h
#define Wavetables_h

extern const uint8_t WAVETABLES[][512] PROGMEM;

#endif
