#include "Arduino.h"

#ifndef FIXED_POINT_MATH_TABLES
  extern const uint16_t fixed_point_sin[] PROGMEM;
  extern const uint16_t fixed_point_exp[] PROGMEM;
#endif

